<?php
/**
 * Class that handles specific [vc_flickr] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_flickr.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_flickr
 */
class WPBakeryShortCode_Vc_Flickr extends WPBakeryShortCode {
}
